class Canvas {
  
  constructor(w, h) {
  	
  	this.canvas = document.createElement("canvas");
  	this.canvas.width = this.width = w;
  	this.canvas.height = this.height = h;
  	this.draw = this.canvas.getContext("2d");
  	document.body.appendChild(this.canvas);
  	this.collision = new Collision(0, 0, this.width, this.height);
  	
  }
  
  rect(x, y, w, h, c) {
  	
  	this.draw.fillStyle = c;
  	this.draw.fillRect(x, y, w, h);
  	
  }
  
  text(text, x, y, colour, size, font, extras) {
    
    if(extras != undefined) {
      
      this.draw.font = extras + " " + size + "px " + font;
      
    } else {
      
      this.draw.font = size + "px " + font;
      
    }
    
  	this.draw.fillStyle = colour;
  	this.draw.textAlign = "center";
  	this.draw.fillText(text, x, y + (size / 2));
    
  }
  
  clear_screen() {
  	
  	this.draw.clearRect(0, 0, this.width, this.height);
  	
  }
  
}

class Player {
  
  constructor(x, y) {
    
    this.spawn(x, y);
    
    this.collision = new Collision(x, y, 18, 18);
    
  }
  
  teleport(x, y) {
    
    this.x = x;
    this.y = y;
    
  }
  
  spawn(x, y) {
    
    this.spawn_x = (screen.width / 2) - 9;
    this.spawn_y = (screen.height / 2) - 9;
    
    this.x = x;
    this.y = y;
    
    this.last_xv = 0;
    this.last_yv = 0;
    
    this.xv = 0;
    this.yv = 0;
    
  }
  
  update() {
    
    this.last_xv = (you.xv / 2) + (you.last_xv / 2);
    this.last_yv = (you.yv / 2) + (you.last_yv / 2);
    
    this.collision = new Collision(this.x, this.y, 18, 18);
    
    for(var count = 0; count < end.collisions.length; count++) {
      
      if(this.collision.collide(end.collisions[count])) {
        
        next_level();
        
      }
      
    }
    
    this.collision_bottom = new Collision(this.x + 2, this.y + 18, 14, 0);
    
    for(var count = 0; count < monsters.length; count++) {
      
      if(this.collision_bottom.collide(monsters[count].collision)) {
        
        monsters.splice(count, 1);
        
        this.yv = -8;
        
        count--;
        
      }
      
    }
    
    this.collision = new Collision(this.x, this.y, 18, 18);
    
    for(var count = 0; count < monsters.length; count++) {
      
      if(this.collision.collide(monsters[count].collision)) {
        
        levels[current_level - 1].load_level();
        
        return 1;
        
      }
      
    }
    
    if((keys[key_codes.left] || keys[key_codes.a]) && !(keys[key_codes.right] || keys[key_codes.d])) {
      
      this.xv += -1;
      
    } else if(!(keys[key_codes.left] || keys[key_codes.a]) && (keys[key_codes.right] || keys[key_codes.d])) {
      
      this.xv += 1;
      
    }
    
    this.xv *= 0.85;
    
    this.x += this.xv;
    
    this.collision = new Collision(this.x, this.y, 18, 18);
    this.touching_world = false;
    
    for(var count1 = 0; count1 < blocks.length; count1++) {
      
      for(var count2 = 0; count2 < blocks[count1].collisions.length; count2++) {
        
        if(this.collision.collide(blocks[count1].collisions[count2])) {
          
          this.touching_world = true;
          
        }
        
      }
      
    }
    
    if(this.touching_world) {
      
      this.x -= this.xv;
      
      this.xv = 0;
      
    }
    
    this.y += this.yv;
    
    this.collision = new Collision(this.x, this.y, 18, 18);
    this.touching_world = false;
    
    for(var count1 = 0; count1 < blocks.length; count1++) {
      
      for(var count2 = 0; count2 < blocks[count1].collisions.length; count2++) {
        
        if(this.collision.collide(blocks[count1].collisions[count2])) {
          
          this.touching_world = true;
          
        }
        
      }
      
    }
    
    if(this.touching_world) {
      
      this.y -= this.yv;
      
      this.yv = 0;
      
      this.y++;
      
      this.collision = new Collision(this.x, this.y, 18, 18);
      this.touching_world = false;
      
      for(var count1 = 0; count1 < blocks.length; count1++) {
        
        for(var count2 = 0; count2 < blocks[count1].collisions.length; count2++) {
          
          if(this.collision.collide(blocks[count1].collisions[count2])) {
            
            this.touching_world = true;
            
          }
          
        }
        
      }
      
      if((keys[key_codes.up] || keys[key_codes.w]) && this.touching_world) {
        
        this.yv = -6.5;
        
      }
      
      this.y--;
      
    } else {
      
      this.yv += 0.25;
      
      if(this.yv > 12) {
        
        this.yv = 12;
        
      }
      
    }
    
    if(this.x > screen.width) {
      
      this.teleport(this.x - screen.width, this.y);
      
    }
    
    if(this.x < 0) {
      
      this.teleport(this.x + screen.width, this.y);
      
    }
    
    if(this.y > screen.height) {
      
      this.teleport(this.x, this.y - screen.height);
      
    }
    
    if(this.y < 0) {
      
      this.teleport(this.x, this.y + screen.height);
      
    }
    
  }
  
  draw() {
    
    screen.rect(this.spawn_x, this.spawn_y, 18, 18, '#000000');
    
  }
  
}

class Monster {
  
  constructor(x, y, direction) {
    
    this.spawn(x, y, direction);
    
    this.collision = new Collision(x, y, 18, 18);
    
  }
  
  teleport(x, y) {
    
    this.x = x;
    this.y = y;
    
  }
  
  spawn(x, y, direction) {
    
    this.x = x;
    this.y = y;
    
    this.xv = (((direction * 2) - 1) * 2);
    this.yv = 0;
    
  }
  
  update() {
    
    this.x += this.xv;
    
    this.collision = new Collision(this.x, this.y, 18, 18);
    this.touching_world = false;
    
    for(var count1 = 0; count1 < blocks.length; count1++) {
      
      for(var count2 = 0; count2 < blocks[count1].collisions.length; count2++) {
        
        if(this.collision.collide(blocks[count1].collisions[count2])) {
          
          this.touching_world = true;
          
        }
        
      }
      
    }
    
    for(var count1 = 0; count1 < barriers.length; count1++) {
      
      for(var count2 = 0; count2 < barriers[count1].collisions.length; count2++) {
        
        if(this.collision.collide(barriers[count1].collisions[count2])) {
          
          this.touching_world = true;
          
        }
        
      }
      
    }
    
    if(this.touching_world) {
      
      this.x -= this.xv;
      
      this.xv *= -1;
      
    }
    
    this.y += this.yv;
    
    this.collision = new Collision(this.x, this.y, 18, 18);
    this.touching_world = false;
    
    for(var count1 = 0; count1 < blocks.length; count1++) {
      
      for(var count2 = 0; count2 < blocks[count1].collisions.length; count2++) {
        
        if(this.collision.collide(blocks[count1].collisions[count2])) {
          
          this.touching_world = true;
          
        }
        
      }
      
    }
    
    if(this.touching_world) {
      
      this.y -= this.yv;
      
      this.yv = 0;
      
    } else {
      
      this.yv += 0.25;
      
      if(this.yv > 12) {
        
        this.yv = 12;
        
      }
      
    }
    
    if(this.x > screen.width) {
      
      this.teleport(this.x - screen.width, this.y);
      
    }
    
    if(this.x < 0) {
      
      this.teleport(this.x + screen.width, this.y);
      
    }
    
    if(this.y > screen.height) {
      
      this.teleport(this.x, this.y - screen.height);
      
    }
    
    if(this.y < 0) {
      
      this.teleport(this.x, this.y + screen.height);
      
    }
    
  }
  
  draw() {
    
    screen.rect(this.x - you.x + you.spawn_x - screen.width, this.y - you.y + you.spawn_y - screen.height, 20, 20, '#B06010');
    screen.rect(this.x - you.x + you.spawn_x               , this.y - you.y + you.spawn_y - screen.height, 20, 20, '#B06010');
    screen.rect(this.x - you.x + you.spawn_x + screen.width, this.y - you.y + you.spawn_y - screen.height, 20, 20, '#B06010');
    screen.rect(this.x - you.x + you.spawn_x - screen.width, this.y - you.y + you.spawn_y                , 20, 20, '#B06010');
    screen.rect(this.x - you.x + you.spawn_x               , this.y - you.y + you.spawn_y                , 20, 20, '#B06010');
    screen.rect(this.x - you.x + you.spawn_x + screen.width, this.y - you.y + you.spawn_y                , 20, 20, '#B06010');
    screen.rect(this.x - you.x + you.spawn_x - screen.width, this.y - you.y + you.spawn_y + screen.height, 20, 20, '#B06010');
    screen.rect(this.x - you.x + you.spawn_x               , this.y - you.y + you.spawn_y + screen.height, 20, 20, '#B06010');
    screen.rect(this.x - you.x + you.spawn_x + screen.width, this.y - you.y + you.spawn_y + screen.height, 20, 20, '#B06010');
    
  }
  
}

class Goal {
  
  constructor(x, y) {
    
    this.x = x;
    this.y = y;
    
    this.collisions = [
      
      new Collision(x - screen.width, y - screen.height, 20, 20),
      new Collision(x               , y - screen.height, 20, 20),
      new Collision(x + screen.width, y - screen.height, 20, 20),
      new Collision(x - screen.width, y                , 20, 20),
      new Collision(x               , y                , 20, 20),
      new Collision(x + screen.width, y                , 20, 20),
      new Collision(x - screen.width, y + screen.height, 20, 20),
      new Collision(x               , y + screen.height, 20, 20),
      new Collision(x + screen.width, y + screen.height, 20, 20)
      
    ]
    
  }
  
  draw() {
    
    screen.rect(this.x - you.x + you.spawn_x - screen.width, this.y - you.y + you.spawn_y - screen.height, 20, 20, '#FFFF00');
    screen.rect(this.x - you.x + you.spawn_x               , this.y - you.y + you.spawn_y - screen.height, 20, 20, '#FFFF00');
    screen.rect(this.x - you.x + you.spawn_x + screen.width, this.y - you.y + you.spawn_y - screen.height, 20, 20, '#FFFF00');
    screen.rect(this.x - you.x + you.spawn_x - screen.width, this.y - you.y + you.spawn_y                , 20, 20, '#FFFF00');
    screen.rect(this.x - you.x + you.spawn_x               , this.y - you.y + you.spawn_y                , 20, 20, '#FFFF00');
    screen.rect(this.x - you.x + you.spawn_x + screen.width, this.y - you.y + you.spawn_y                , 20, 20, '#FFFF00');
    screen.rect(this.x - you.x + you.spawn_x - screen.width, this.y - you.y + you.spawn_y + screen.height, 20, 20, '#FFFF00');
    screen.rect(this.x - you.x + you.spawn_x               , this.y - you.y + you.spawn_y + screen.height, 20, 20, '#FFFF00');
    screen.rect(this.x - you.x + you.spawn_x + screen.width, this.y - you.y + you.spawn_y + screen.height, 20, 20, '#FFFF00');
    
  }
  
}

class Block {
  
  constructor(x, y) {
    
    this.x = x;
  	this.y = y;
    
    this.collisions = [
      
      new Collision(x - screen.width, y - screen.height, 20, 20),
      new Collision(x               , y - screen.height, 20, 20),
      new Collision(x + screen.width, y - screen.height, 20, 20),
      new Collision(x - screen.width, y                , 20, 20),
      new Collision(x               , y                , 20, 20),
      new Collision(x + screen.width, y                , 20, 20),
      new Collision(x - screen.width, y + screen.height, 20, 20),
      new Collision(x               , y + screen.height, 20, 20),
      new Collision(x + screen.width, y + screen.height, 20, 20)
        
    ]
    
  }
  
  draw() {
    
    screen.rect(this.x - you.x + you.spawn_x - screen.width, this.y - you.y + you.spawn_y - screen.height, 20, 20, '#00A000');
    screen.rect(this.x - you.x + you.spawn_x               , this.y - you.y + you.spawn_y - screen.height, 20, 20, '#00A000');
    screen.rect(this.x - you.x + you.spawn_x + screen.width, this.y - you.y + you.spawn_y - screen.height, 20, 20, '#00A000');
    screen.rect(this.x - you.x + you.spawn_x - screen.width, this.y - you.y + you.spawn_y                , 20, 20, '#00A000');
    screen.rect(this.x - you.x + you.spawn_x               , this.y - you.y + you.spawn_y                , 20, 20, '#00A000');
    screen.rect(this.x - you.x + you.spawn_x + screen.width, this.y - you.y + you.spawn_y                , 20, 20, '#00A000');
    screen.rect(this.x - you.x + you.spawn_x - screen.width, this.y - you.y + you.spawn_y + screen.height, 20, 20, '#00A000');
    screen.rect(this.x - you.x + you.spawn_x               , this.y - you.y + you.spawn_y + screen.height, 20, 20, '#00A000');
    screen.rect(this.x - you.x + you.spawn_x + screen.width, this.y - you.y + you.spawn_y + screen.height, 20, 20, '#00A000');
    
  }
  
}

class Barrier {
  
  constructor(x, y) {
    
    this.x = x;
  	this.y = y;
    
    this.collisions = [
      
      new Collision(x - screen.width, y - screen.height, 20, 20),
      new Collision(x               , y - screen.height, 20, 20),
      new Collision(x + screen.width, y - screen.height, 20, 20),
      new Collision(x - screen.width, y                , 20, 20),
      new Collision(x               , y                , 20, 20),
      new Collision(x + screen.width, y                , 20, 20),
      new Collision(x - screen.width, y + screen.height, 20, 20),
      new Collision(x               , y + screen.height, 20, 20),
      new Collision(x + screen.width, y + screen.height, 20, 20)
        
    ]
    
  }
  
}

class Level {
  
  constructor(title, captions, game_components) {
    
    this.title = title;
    this.captions = captions;
    this.captions.push("");
    this.captions.push("(press [enter]");
    this.captions.push("to continue)");
    this.game_components = game_components;
    
    this.ready_for_load = false;
    
  }
  
  load_level() {
    
    screen.clear_screen();
    
    monsters = [];
    blocks = [];
    barriers = [];
    
    for(var y = 0; y < this.game_components.length; y++) {
      
      for(var x = 0; x < this.game_components[y].length; x++) {
        
        switch(this.game_components[y][x]) {
          
          case 0: break;
          
          case 1: blocks.push(new Block(x * 20, y * 20)); break;
          
          case 2: you.spawn(x * 20, (y * 20) - 1); break;
          
          case 3: end = new Goal(x * 20, y * 20); break;
          
          case 4: monsters.push(new Monster(x * 20, y * 20, 0)); break;
          
          case 5: monsters.push(new Monster(x * 20, y * 20, 1)); break;
          
          case 6: barriers.push(new Barrier(x * 20, y * 20)); break;
          
        }
        
      }
      
    }
    
  }
  
}

class Collision {
  
  constructor(x, y, w, h) {
  
  	this.x = x;
  	this.y = y;
    this.h = h;
  	this.w = w;
  
  }
  
  collide(other) {
    
    return ((this.x < (other.x + other.w)) && ((this.x + this.w) > other.x) && (this.y < (other.y + other.h)) && ((this.y + this.h) > other.y));
    
  }
  
}

function next_level() {
  
  current_level++;
  if(current_level > levels.length) {
    
    current_level = 1;
    
  }
  
  loading_level = 1;
  in_title = true;
  
}

function begin() {
  
  init();
  
  window.requestAnimationFrame(game);
  
}

function init() {
  
  // document.body.style.margin = "0px 0px 0px 0px";
  
  frame = 0;
  
  keys = {};
  
  document.addEventListener("keydown", function(key) {
    
    keys[key.keyCode] = true;
    
  });
  
  document.addEventListener("keyup", function(key) {
    
    delete keys[key.keyCode];
    
  });
  
  key_codes = {
    
    up: 38,
    left: 37,
    down: 40,
    right: 39,
    
    w: 87,
    a: 65,
    s: 83,
    d: 68,
    
  }
  
  screen = new Canvas(400, 400);
  
  screen.canvas.style.border = "5px solid black";
  screen.canvas.style.position = "absolute";
  screen.canvas.style.margin = "auto";
  screen.canvas.style.top = "0px";
  screen.canvas.style.left = "0px";
  screen.canvas.style.bottom = "0px";
  screen.canvas.style.right = "0px";
  
  /*
  screen.canvas.style.borderLeft = "5px solid #D08000";
  screen.canvas.style.borderTop = "5px solid #F0A000";
  screen.canvas.style.borderRight = "5px solid blue";
  screen.canvas.style.borderBottom = "5px solid blue";
  screen.canvas.style.borderRadius = "5%";
  */
  
  you = new Player(0, 0);
  end = new Goal(0, 0);
  monsters = [];
  blocks = [];
  barriers = [];
  
  levels = [
    
    new Level("The Beginning", ["Use the arrow", "keys to move.", "(or wasd)", "", "Get to the yellow", "square to win!"], [
      
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 3, 0, 0, 1, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0],
      [0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0],
      [0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      
    ]),
    
    new Level("Monsters!", ["Jump on enemies", "heads to kill them!"], [
      
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      
    ]),
    
    new Level("Maze", ["Sometimes...", "", "...there are many", "ways to get", "to one goal..."], [
      
      [1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1],
      [1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0],
      [1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
      [1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 2, 0, 1, 1, 1],
      [1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1],
      
    ]),
    
    new Level("Staircase", ["...Sometimes", "", "paths are simpler", "than we may think..."], [
      
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0],
      [1, 1, 0, 0, 0, 0, 0, 0, 5, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
      [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
      [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 5, 0],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1],
      [1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1],
      [1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 1, 0, 0, 0, 0, 0, 0, 5, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
      [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 2, 0, 0, 1, 1, 0, 0, 0, 0, 0]
      
    ]),
    
  new Level("The Pillars", ["...Sometimes", "", "we must", "find creative ways", "to resolve", "our problem..."], [
    
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 2, 0, 0, 0, 0, 6, 0, 4, 0, 0, 6, 0, 0, 6, 0, 3, 4, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1],
    [1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1]
    
  ]),
  
  new Level("Freefall", ["Sometimes...", "", "...you have to", "take a leap...", "", "...a leap", "of faith!"], [
    
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0],
    [1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1]
    
  ])
    
  ];
  
  current_level = 0;
  next_level();
  
}

function game() {
  
  /*
  frame++;
  
  if(frame > 1000) {
    
    frame = 0;
    
  }
  */
  
  screen.clear_screen();
  
  if(!loading_level) {
    
    you.update();
    for(var count = 0; count < monsters.length; count++) {
      
      monsters[count].update();
      
    }
    
    screen.rect(0, 0, screen.width, screen.height, "#F8F8F8");
    screen.text(levels[current_level - 1].title, screen.width / 2 - (you.last_xv * (0.0025 * screen.width)), screen.height / 4 - (you.last_yv * (0.0041 * screen.height)), "white", (0.1 * screen.width).toString(), "arial");
    end.draw();
    for(var count = 0; count < monsters.length; count++) {
      
      monsters[count].draw();
      
    }
    you.draw();
    for(var count = 0; count < blocks.length; count++) {
      
      blocks[count].draw();
      
    }
    
  }
  
  if(loading_level && in_title) {
    
    if((screen.height == levels[current_level - 1].game_components.length * 20) && (screen.width == levels[current_level - 1].game_components[0].length * 20) && keys[13]) {
      
      in_title = false;
      
    } else {
      
      screen.width += (levels[current_level - 1].game_components[0].length * 20 - screen.width) / 16;
      screen.canvas.width = screen.width;
      if(Math.abs((levels[current_level - 1].game_components[0].length * 20) - screen.width) < 5) {
        
        screen.width = screen.canvas.width = levels[current_level - 1].game_components[0].length * 20;
        
      }
      
      screen.height += (levels[current_level - 1].game_components.length * 20 - screen.height) / 16;
      screen.canvas.height = screen.height;
      if(Math.abs((levels[current_level - 1].game_components.length * 20) - screen.height) < 5) {
        
        screen.height = screen.canvas.height = levels[current_level - 1].game_components.length * 20;
        
      }
      
      screen.rect(0, 0, Math.max(screen.width, levels[current_level - 1].game_components[0].length * 20), Math.max(screen.height, levels[current_level - 1].game_components.length * 20), "black");
      screen.text(levels[current_level - 1].title, screen.width / 2, screen.height / 4.5, "white", (0.125 * screen.height).toString(), "courier", "bold");
      for(var count = 0; count < levels[current_level - 1].captions.length; count++) {
        
        screen.text(levels[current_level - 1].captions[count], screen.width / 2, screen.height / 1.5 + (count * (0.0625 * screen.height)) - ((levels[current_level - 1].captions.length * (0.0625 * screen.height)) / 2), "white", (0.0625 * screen.height).toString(), "courier");
        
      }
      
    }
    
  } else if(loading_level && !in_title) {
    
    levels[current_level - 1].load_level();
    
    loading_level = 0;
    
  }
  
  window.requestAnimationFrame(game);
  
}

begin();